const terminals = [];
const maxTerminals = 10;
let currentZ = 10;

function createTerminal() {
    if (terminals.length >= maxTerminals) {
        alert('Maximum of 10 terminals reached.');
        return;
    }

    const win = document.createElement('div');
    win.className = 'terminal-window';
    win.style.left = (Math.random() * 300 + 50) + 'px';
    win.style.top = (Math.random() * 300 + 50) + 'px';
    win.style.zIndex = currentZ++;
    win.innerHTML = `
        <div class="title-bar">
            Terminal
            <button class="close-btn" onclick="closeTerminal(this)">×</button>
        </div>
        <div class="terminal-content">
            <div class="output">
                <div>$ Welcome to the terminal!</div>
                <div>> </div>
            </div>
            <input type="text" class="cmd-input" placeholder="$ " onkeypress="handleCmd(event, this)" autofocus>
        </div>
    `;
    document.body.appendChild(win);
    makeDraggable(win);
    addFocusHandler(win);
    terminals.push(win);
}

function addFocusHandler(win) {
    win.addEventListener('click', function(e) {
        if (!e.target.closest('.title-bar') && !e.target.closest('.close-btn')) {
            win.style.zIndex = currentZ++;
            const input = win.querySelector('.cmd-input');
            input.focus();
        }
    });
}

function newTerminal() {
    createTerminal();
    hideContextMenu();
}

function closeTerminal(btn) {
    const win = btn.closest('.terminal-window');
    win.remove();
    terminals.splice(terminals.indexOf(win), 1);
}

function handleCmd(e, input) {
    if (e.key === 'Enter') {
        const cmd = input.value.trim();
        const output = input.parentElement.querySelector('.output');
        output.innerHTML += `<div>$${cmd}</div><div>> ${cmd || '(empty command executed)'}</div>`;
        output.scrollTop = output.scrollHeight;
        input.value = '';
    }
}

function makeDraggable(el) {
    let pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
    const titleBar = el.querySelector('.title-bar');
    titleBar.onmousedown = dragMouseDown;

    function dragMouseDown(e) {
        e.preventDefault();
        pos3 = e.clientX;
        pos4 = e.clientY;
        document.onmouseup = closeDrag;
        document.onmousemove = elementDrag;
    }

    function elementDrag(e) {
        e.preventDefault();
        pos1 = pos3 - e.clientX;
        pos2 = pos4 - e.clientY;
        pos3 = e.clientX;
        pos4 = e.clientY;
        el.style.top = (el.offsetTop - pos2) + 'px';
        el.style.left = (el.offsetLeft - pos1) + 'px';
    }

    function closeDrag() {
        document.onmouseup = null;
        document.onmousemove = null;
    }
}

function dummyOption1() {
    console.log('Dummy Option 1 clicked');
    hideContextMenu();
}

function dummyOption2() {
    console.log('Dummy Option 2 clicked');
    hideContextMenu();
}

function customize() {
    document.getElementById('customize-panel').style.display = 'flex';
    hideContextMenu();
}

function closeCustomize() {
    document.getElementById('customize-panel').style.display = 'none';
}

function openTestPanel() {
    document.getElementById('test-panel').style.display = 'flex';
}

function closeTestPanel() {
    document.getElementById('test-panel').style.display = 'none';
}

function updateTheme() {
    document.documentElement.style.setProperty('--bg-color', document.getElementById('bg-color').value);
    document.documentElement.style.setProperty('--text-color', document.getElementById('text-color').value);
    document.documentElement.style.setProperty('--font-family', document.getElementById('font-family').value);
    document.documentElement.style.setProperty('--terminal-bg', document.getElementById('terminal-bg').value);
    document.documentElement.style.setProperty('--terminal-text', document.getElementById('terminal-text').value);
    document.documentElement.style.setProperty('--title-bg', document.getElementById('title-bg').value);
    document.documentElement.style.setProperty('--title-text', document.getElementById('title-text').value);
    document.documentElement.style.setProperty('--toolbar-bg', document.getElementById('toolbar-bg').value);
    document.documentElement.style.setProperty('--toolbar-text', document.getElementById('toolbar-text').value);
    document.documentElement.style.setProperty('--context-bg', document.getElementById('context-bg').value);
    document.documentElement.style.setProperty('--context-text', document.getElementById('context-text').value);
    document.documentElement.style.setProperty('--context-hover', document.getElementById('context-hover').value);
}

function hideContextMenu() {
    document.getElementById('context-menu').style.display = 'none';
}

// Event listeners
document.addEventListener('DOMContentLoaded', function() {
    console.log('DOMContentLoaded fired');
    
    document.getElementById('term-btn').onclick = createTerminal;

    // Add event listener for Settings button
    const settingsBtn = document.getElementById('settings-btn');
    console.log('Settings button element:', settingsBtn);
    if (settingsBtn) {
        settingsBtn.addEventListener('click', function() {
            console.log('Settings button clicked!');
            customize();
        });
        console.log('Event listener added to Settings button');
    } else {
        console.log('Settings button not found!');
    }

    // Add event listener for Files button
    const filesBtn = document.getElementById('files-btn');
    console.log('Files button element:', filesBtn);
    if (filesBtn) {
        filesBtn.addEventListener('click', function() {
            // You can add files functionality here if needed
            console.log('Files button clicked');
        });
        console.log('Event listener added to Files button');
    }

    // Add event listener for Test button
    const testBtn = document.getElementById('test-btn');
    console.log('Test button element:', testBtn);
    if (testBtn) {
        testBtn.addEventListener('click', function() {
            console.log('Test button clicked!');
            openTestPanel();
        });
        console.log('Event listener added to Test button');
    } else {
        console.log('Test button not found!');
    }

    document.addEventListener('contextmenu', (e) => {
        e.preventDefault();
        const menu = document.getElementById('context-menu');
        menu.style.display = 'block';
        menu.style.left = e.pageX + 'px';
        menu.style.top = e.pageY + 'px';
    });

    document.addEventListener('click', function(e) {
        const contextMenu = document.getElementById('context-menu');
        const customizePanel = document.getElementById('customize-panel');
        const testPanel = document.getElementById('test-panel');
        
        // Check if the click is outside the context menu and the menu is visible
        if (contextMenu.offsetParent !== null && !contextMenu.contains(e.target)) {
            hideContextMenu();
        }
        
        // Check if the click is outside the customize panel and the panel is visible
        if (customizePanel.offsetParent !== null && !customizePanel.contains(e.target)) {
            closeCustomize();
        }
        
        // Check if the click is outside the test panel and the panel is visible
        if (testPanel.offsetParent !== null && !testPanel.contains(e.target)) {
            closeTestPanel();
        }
    });
});