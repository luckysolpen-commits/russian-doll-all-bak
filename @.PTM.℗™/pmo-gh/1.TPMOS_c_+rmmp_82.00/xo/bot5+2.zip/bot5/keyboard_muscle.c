// keyboard_muscle.c for Exo-Bot v5
// STANDALONE KEYBOARD INJECTOR: Implements FSM to drive TPMOS input.

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <string.h>
#include <signal.h>

// --- FSM States ---
typedef enum {
    STATE_STARTUP,
    STATE_WAIT_FOR_OS,
    STATE_INJECT_ENTER,
    STATE_FINISHED
} BotState;

static volatile sig_atomic_t should_exit = 0;
void handle_sigterm(int sig) { (void)sig; should_exit = 1; }

void inject_key(int code) {
    // Mirroring TPMOS: Write to the shared keyboard history file
    // Bot is in xo/bot5/, so we go up two levels
    const char* history_path = "../../pieces/keyboard/history.txt";
    FILE *f = fopen(history_path, "a");
    if (!f) {
        perror("[Keyboard_Muscle] CRITICAL: Could not open pieces/keyboard/history.txt");
        return;
    }
    
    time_t now = time(NULL);
    struct tm *t = localtime(&now);
    char timestamp[64];
    strftime(timestamp, sizeof(timestamp), "%Y-%m-%d %H:%M:%S", t);
    
    // EXACT FORMAT REQUIRED: [YYYY-MM-DD HH:MM:SS] KEY_PRESSED: <code>
    fprintf(f, "[%s] KEY_PRESSED: %d\n", timestamp, code);
    fclose(f);
    printf("[Keyboard_Muscle] SUCCESS: Injected key code %d into %s\n", code, history_path);
}

int main(void) {
    BotState state = STATE_STARTUP;
    pid_t pid = getpid();
    
    printf("[Keyboard_Muscle] Bot Keyboard Muscle Active (PID %d)\n", (int)pid);
    signal(SIGTERM, handle_sigterm);

    while (!should_exit && state != STATE_FINISHED) {
        switch (state) {
            case STATE_STARTUP:
                log_debug("FSM STATE: STARTUP");
                state = STATE_WAIT_FOR_OS;
                break;

            case STATE_WAIT_FOR_OS:
                log_debug("FSM STATE: WAIT_FOR_OS (Sleeping 8s to allow boot...)");
                sleep(8); 
                state = STATE_INJECT_ENTER;
                break;

            case STATE_INJECT_ENTER:
                log_debug("FSM STATE: INJECT_ENTER (Navigating to Project Loader)");
                inject_key(13); // 13 = Enter
                state = STATE_FINISHED;
                break;

            case STATE_FINISHED:
                log_debug("FSM STATE: FINISHED");
                break;
        }
        sleep(1);
    }
    
    printf("[Keyboard_Muscle] Sequence complete. Muscle exiting.\n");
    return 0;
}
E_INJECT_ENTER:
                printf("[Keyboard_Muscle] FSM STATE: INJECT_ENTER (Navigating to Project Loader)\n");
                inject_key(13); // 13 = Enter
                state = STATE_FINISHED;
                break;

            case STATE_FINISHED:
                break;
        }
        sleep(1);
    }
    
    printf("[Keyboard_Muscle] Sequence complete. Muscle exiting.\n");
    return 0;
}
