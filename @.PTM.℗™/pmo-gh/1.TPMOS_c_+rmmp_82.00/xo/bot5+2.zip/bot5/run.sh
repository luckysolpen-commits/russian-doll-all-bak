#!/bin/bash
# run.sh for Bot5
# Executes the orchestrator.

BOT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$BOT_DIR"

if [ ! -f "./bot5_orchestrator" ]; then
    echo "Executable not found. Running build.sh first..."
    bash build.sh
fi

echo "=== Launching Bot5 (Pure Orchestration) ==="
./bot5_orchestrator
