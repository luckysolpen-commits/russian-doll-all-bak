// orchestrator.c for Exo-Bot v5
// PURE ORCHESTRATION: Launches children as standalone binaries.
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <sys/wait.h>
#include <string.h>
#include <fcntl.h>
#include <sys/file.h>

#define PROC_LIST "proc_list.txt"

// --- Local Declarations ---
static void log_pid(pid_t pid, const char* name) {
    FILE* f = fopen(PROC_LIST, "a");
    if (!f) return;
    flock(fileno(f), LOCK_EX);
    fprintf(f, "%d %s\n", (int)pid, name);
    fflush(f);
    flock(fileno(f), LOCK_UN);
    fclose(f);
}

static void kill_tracked_processes(void) {
    printf("\n[Orchestrator] Cleaning up child processes...\n");
    FILE* f = fopen(PROC_LIST, "r");
    if (!f) return;
    char line[128];
    while (fgets(line, sizeof(line), f)) {
        int pid;
        char name[64];
        if (sscanf(line, "%d %63s", &pid, name) == 2) {
            printf("[Orchestrator] Sending SIGTERM to %s (PID %d)\n", name, pid);
            kill(pid, SIGTERM);
        }
    }
    fclose(f);
    // Clear list
    f = fopen(PROC_LIST, "w");
    if (f) fclose(f);
}

void handle_sigint(int sig) {
    (void)sig;
    kill_tracked_processes();
    exit(0);
}

static int execute_system_command(const char* script, const char* arg) {
    printf("[Orchestrator] EXECUTING SYSTEM COMMAND: %s %s\n", script, arg);
    pid_t pid = fork();
    if (pid == 0) {
        // Navigate to project root for system scripts
        if (chdir("../..") != 0) {
            perror("chdir to root failed");
            exit(1);
        }
        execl("/bin/bash", "bash", script, arg, (char*)NULL);
        perror("execl system command failed");
        exit(1);
    } else if (pid > 0) {
        int status;
        waitpid(pid, &status, 0);
        if (WIFEXITED(status)) {
            int exit_code = WEXITSTATUS(status);
            printf("[Orchestrator] System command finished with exit code %d\n", exit_code);
            return exit_code;
        }
    }
    return -1;
}

int main(int argc, char *argv[]) {
    if (argc < 2) {
        fprintf(stderr, "Usage: %s <target_tpmos_directory>\n", argv[0]);
        return 1;
    }
    const char* target_dir = argv[1];

    printf("=== Bot5 Orchestrator Starting ===\n");

    // Phase 0: System Compilation
    execute_system_command("button.sh", "r");

    // Clear stale proc list
    FILE* init_f = fopen(PROC_LIST, "w");
    if (init_f) fclose(init_f);

    signal(SIGINT, handle_sigint);

    // Launch Keyboard Muscle (The Bot's "Hand")
    pid_t pid_kb = fork();
    if (pid_kb == 0) {
        // Pass target_dir so child knows project root
        execl("./bot5_keyboard_muscle", "bot5_keyboard_muscle", target_dir, (char*)NULL);
        perror("execl failed for bot5_keyboard_muscle");
        exit(1);
    } else if (pid_kb > 0) {
        log_pid(pid_kb, "Keyboard_Hand");
        printf("[Orchestrator] Launched Keyboard_Hand (PID %d)\n", (int)pid_kb);
    }

    printf("[Orchestrator] Monitoring. Press Ctrl+C to stop.\n");

    // Main loop: wait for children or signals
    while (1) {
        int status;
        pid_t dead_child = waitpid(-1, &status, WNOHANG);
        if (dead_child > 0) {
            printf("[Orchestrator] Child %d exited.\n", (int)dead_child);
        }
        sleep(1);
    }

    return 0;
}
