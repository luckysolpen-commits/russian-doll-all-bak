// keyboard_muscle.c for Exo-Bot v5
// STANDALONE KEYBOARD INJECTOR: Implements FSM to drive TPMOS input.
#define _GNU_SOURCE  // Enable asprintf (GNU extension)
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <string.h>
#include <signal.h>
#include <sys/stat.h>

// --- FSM States ---
typedef enum {
    STATE_STARTUP,
    STATE_WAIT_FOR_OS,
    STATE_INJECT_ENTER,
    STATE_FINISHED
} BotState;

static volatile sig_atomic_t should_exit = 0;
static char g_target_dir[1024];  // Project root path

void handle_sigterm(int sig) { 
    (void)sig; 
    should_exit = 1; 
}

// Debug logging relative to project root using asprintf
void log_debug(const char* message) {
    char *debug_path = NULL;
    char *dir_path = NULL;
    
    // Construct paths dynamically
    if (asprintf(&debug_path, "%s/xo/bot5/debug/muscle_log.txt", g_target_dir) < 0 ||
        asprintf(&dir_path, "%s/xo/bot5/debug", g_target_dir) < 0) {
        perror("[Keyboard_Muscle] asprintf failed for debug paths");
        free(debug_path);
        free(dir_path);
        return;
    }
    
    // Ensure directory exists
    mkdir(dir_path, 0755);
    
    FILE *f = fopen(debug_path, "a");
    if (f) {
        time_t now = time(NULL);
        struct tm *t = localtime(&now);
        char timestamp[64];
        strftime(timestamp, sizeof(timestamp), "%Y-%m-%d %H:%M:%S", t);
        fprintf(f, "[%s] %s\n", timestamp, message);
        fclose(f);
    } else {
        perror("[Keyboard_Muscle] ERROR: Could not open debug log file");
    }
    
    free(debug_path);
    free(dir_path);
}

// Inject key to shared history file using asprintf
void inject_key(int code) {
    char *history_path = NULL;
    
    if (asprintf(&history_path, "%s/pieces/keyboard/history.txt", g_target_dir) < 0) {
        perror("[Keyboard_Muscle] asprintf failed for history path");
        return;
    }
    
    FILE *f = fopen(history_path, "a");
    if (!f) {
        char *err_msg = NULL;
        if (asprintf(&err_msg, "ERROR: Could not open global history file %s", history_path) >= 0) {
            log_debug(err_msg);
            free(err_msg);
        }
        free(history_path);
        return;
    }
    
    time_t now = time(NULL);
    struct tm *t = localtime(&now);
    char timestamp[64];
    strftime(timestamp, sizeof(timestamp), "%Y-%m-%d %H:%M:%S", t);
    
    fprintf(f, "[%s] KEY_PRESSED: %d\n", timestamp, code);
    fclose(f);
    
    // Log success message
    char *msg = NULL;
    if (asprintf(&msg, "SUCCESS: Injected key code %d into %s", code, history_path) >= 0) {
        log_debug(msg);
        free(msg);
    }
    
    free(history_path);
}

int main(int argc, char *argv[]) {
    if (argc < 2) {
        fprintf(stderr, "Usage: %s <target_tpmos_directory>\n", argv[0]);
        return 1;
    }
    
    // Store and validate target directory
    strncpy(g_target_dir, argv[1], sizeof(g_target_dir) - 1);
    g_target_dir[sizeof(g_target_dir) - 1] = '\0';
    
    // Set working directory to project root for consistent relative paths
    if (chdir(g_target_dir) != 0) {
        perror("Keyboard_Muscle: Failed to chdir to target directory");
        return 1;
    }
    
    BotState state = STATE_STARTUP;
    pid_t pid = getpid();
    
    log_debug("--- NEW SESSION ---");
    char *start_msg = NULL;
    if (asprintf(&start_msg, "Bot Keyboard Muscle Active (PID %d)", (int)pid) >= 0) {
        log_debug(start_msg);
        free(start_msg);
    }
    
    signal(SIGTERM, handle_sigterm);
    signal(SIGINT, handle_sigterm);

    while (!should_exit && state != STATE_FINISHED) {
        switch (state) {
            case STATE_STARTUP:
                log_debug("FSM STATE: STARTUP");
                state = STATE_WAIT_FOR_OS;
                break;
            case STATE_WAIT_FOR_OS:
                log_debug("FSM STATE: WAIT_FOR_OS (Sleeping 8s to allow boot...)");
                sleep(8);
                state = STATE_INJECT_ENTER;
                break;
            case STATE_INJECT_ENTER:
                log_debug("FSM STATE: INJECT_ENTER (Navigating to Project Loader)");
                inject_key(13); // 13 = Enter
                state = STATE_FINISHED;
                break;
            case STATE_FINISHED:
                log_debug("FSM STATE: FINISHED");
                break;
        }
        sleep(1);
    }

    log_debug("Sequence complete. Muscle exiting.");
    return 0;
}
