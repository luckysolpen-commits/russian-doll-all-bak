#!/bin/bash
# run.sh for Bot5
# Executes the orchestrator with project root argument.

BOT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$BOT_DIR"

# Build if executable missing
if [ ! -f "./bot5_orchestrator" ]; then
    echo "Executable not found. Running build.sh first..."
    bash build.sh || exit 1
fi

# Resolve project root (two levels up from xo/bot5)
PROJECT_ROOT="$(cd "$BOT_DIR/../.." && pwd)"

echo "=== Launching Bot5 (Pure Orchestration) ==="
echo "Project root: $PROJECT_ROOT"

# Pass project root so children can resolve paths correctly
./bot5_orchestrator "$PROJECT_ROOT"
