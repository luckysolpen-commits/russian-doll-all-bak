// orchestrator.c for Exo-Bot v5
// STAYS ALIVE: Manages setup, launches muscle, monitors children until SIGINT.
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <sys/wait.h>
#include <string.h>
#include <sys/file.h>
#include <errno.h>

#define PROC_LIST "proc_list.txt"
static char g_project_root[1024] = ".";
static volatile sig_atomic_t should_exit = 0;

void handle_sigint(int sig) { (void)sig; should_exit = 1; }

static void log_pid(pid_t pid, const char* name) {
    FILE* f = fopen(PROC_LIST, "a");
    if (!f) return;
    flock(fileno(f), LOCK_EX);
    fprintf(f, "%d %s\n", (int)pid, name);
    fflush(f);
    flock(fileno(f), LOCK_UN);
    fclose(f);
}

static int run_system_cmd(const char* script, const char* arg) {
    fprintf(stderr, "[Orchestrator] SETUP: Running %s %s\n", script, arg);
    pid_t pid = fork();
    if (pid == 0) {
        if (chdir(g_project_root) != 0) { perror("chdir setup failed"); exit(1); }
        execl("/bin/bash", "bash", script, arg, (char*)NULL);
        perror("execl setup failed");
        exit(1);
    } else if (pid > 0) {
        int status;
        waitpid(pid, &status, 0); // Wait for build/setup to finish
        return WIFEXITED(status) ? WEXITSTATUS(status) : -1;
    }
    return -1;
}

int main(int argc, char *argv[]) {
    // 1️⃣ Resolve & store project root
    if (argc > 1) {
        strncpy(g_project_root, argv[1], sizeof(g_project_root)-1);
        g_project_root[sizeof(g_project_root)-1] = '\0';
    } else {
        getcwd(g_project_root, sizeof(g_project_root));
    }
    fprintf(stderr, "[Orchestrator] STARTUP. Root: %s\n", g_project_root);

    signal(SIGINT, handle_sigint);
    signal(SIGTERM, handle_sigint);

    // 2️⃣ Phase 0: Setup/Build
    run_system_cmd("button.sh", "r");

    // Clear stale proc list
    FILE* f = fopen(PROC_LIST, "w"); if(f) fclose(f);

    // 3️⃣ Launch Muscle
    pid_t muscle_pid = fork();
    if (muscle_pid == 0) {
        execl("./bot5_keyboard_muscle", "bot5_keyboard_muscle", g_project_root, (char*)NULL);
        perror("[Orchestrator] Muscle execl failed");
        exit(1);
    } else if (muscle_pid > 0) {
        log_pid(muscle_pid, "Keyboard_Hand");
        fprintf(stderr, "[Orchestrator] Launched Muscle PID %d\n", (int)muscle_pid);
    }

    // 4️⃣ MONITORING LOOP (STAYS ALIVE)
    fprintf(stderr, "[Orchestrator] Entering monitoring loop (Ctrl+C to exit)...\n");
    while (!should_exit) {
        pid_t dead;
        int status;
        // Reap any exited children without blocking
        while ((dead = waitpid(-1, &status, WNOHANG)) > 0) {
            fprintf(stderr, "[Orchestrator] Process %d exited (status %d)\n", (int)dead, WEXITSTATUS(status));
        }
        sleep(1);
    }

    // Graceful shutdown
    fprintf(stderr, "[Orchestrator] Shutdown signal received. Cleaning up...\n");
    kill(muscle_pid, SIGTERM);
    return 0;
}
