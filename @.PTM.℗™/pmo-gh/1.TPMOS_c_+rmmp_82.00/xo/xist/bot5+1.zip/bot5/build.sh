#!/bin/bash
# build.sh for Bot5
# PURE COMPILATION - NO LINKING BETWEEN MODULES

BOT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$BOT_DIR"

echo "--- Building Bot5 Orchestrator ---"
gcc -Wall -Wextra -O2 orchestrator.c -o bot5_orchestrator

echo "--- Building Bot5 Muscle Binary ---"
gcc -Wall -Wextra -O2 child_process.c -o bot5_child

echo "--- Build Complete ---"
ls -l bot5_orchestrator bot5_child
