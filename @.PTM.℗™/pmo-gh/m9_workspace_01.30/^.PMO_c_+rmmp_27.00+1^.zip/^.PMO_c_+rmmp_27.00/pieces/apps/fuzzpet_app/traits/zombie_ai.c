#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <ctype.h>
#include <stdarg.h>
#include <time.h>

// TPM Zombie AI Trait (v1.3 - PULSE TRIGGER)
// Responsibility: Calculate step toward target and signal renderer.

char *project_root = NULL;

char* trim_str(char *str) {
    char *end;
    while(isspace((unsigned char)*str)) str++;
    if(*str == 0) return str;
    end = str + strlen(str) - 1;
    while(end > str && isspace((unsigned char)*end)) end--;
    end[1] = '\0';
    return str;
}

void log_debug(const char* fmt, ...) {
    if (!project_root) return;
    char *path = NULL; asprintf(&path, "%s/pieces/apps/fuzzpet_app/manager/debug_log.txt", project_root);
    FILE *f = fopen(path, "a");
    if (f) {
        va_list args; va_start(args, fmt);
        time_t now = time(NULL);
        fprintf(f, "[%ld] [AI] ", now);
        vfprintf(f, fmt, args);
        fprintf(f, "\n");
        va_end(args);
        fclose(f);
    }
    free(path);
}

void resolve_paths() {
    const char* attempts[] = {"pieces/locations/location_kvp", "../pieces/locations/location_kvp", "../../pieces/locations/location_kvp", "../../../pieces/locations/location_kvp"};
    for (int i = 0; i < 4; i++) {
        FILE *kvp = fopen(attempts[i], "r");
        if (kvp) {
            char line[4096];
            while (fgets(line, sizeof(line), kvp)) {
                if (strncmp(line, "project_root=", 13) == 0) {
                    project_root = strdup(trim_str(line + 13));
                    fclose(kvp); return;
                }
            }
            fclose(kvp);
        }
    }
}

int get_state_int(const char* piece_id, const char* key) {
    if (!project_root) return -1;
    char *path = NULL; asprintf(&path, "%s/pieces/world/map_01/%s/state.txt", project_root, piece_id);
    if (access(path, F_OK) != 0) {
        free(path);
        if (strcmp(piece_id, "selector") == 0) asprintf(&path, "%s/pieces/apps/fuzzpet_app/selector/state.txt", project_root);
        else if (strstr(piece_id, "zombie") != NULL) asprintf(&path, "%s/pieces/world/map_01/%s/state.txt", project_root, piece_id);
        else if (strstr(piece_id, "pet") != NULL) asprintf(&path, "%s/pieces/world/map_01/%s/state.txt", project_root, piece_id);
        else return -1;
    }
    FILE *f = fopen(path, "r");
    if (!f) { free(path); return -1; }
    char line[4096]; int val = -1;
    while (fgets(line, sizeof(line), f)) {
        char *eq = strchr(line, '=');
        if (eq) {
            *eq = '\0';
            if (strcmp(trim_str(line), key) == 0) { val = atoi(trim_str(eq + 1)); break; }
        }
    }
    fclose(f); free(path);
    return val;
}

int main(int argc, char *argv[]) {
    if (argc < 3) return 1;
    resolve_paths();
    if (!project_root) return 1;

    char *zombie_id = argv[1];
    char *target_id = argv[2];

    int zx = get_state_int(zombie_id, "pos_x");
    int zy = get_state_int(zombie_id, "pos_y");
    int tx = get_state_int(target_id, "pos_x");
    int ty = get_state_int(target_id, "pos_y");

    if (zx == -1 || tx == -1) return 1;

    int dx = (tx > zx) ? 1 : (tx < zx ? -1 : 0);
    int dy = (ty > zy) ? 1 : (ty < zy ? -1 : 0);

    int nx = zx, ny = zy;
    if (dx != 0) nx += dx; else if (dy != 0) ny += dy;

    if (nx < 1) nx = 1; if (nx > 18) nx = 18;
    if (ny < 1) ny = 1; if (ny > 8) ny = 8;

    char *cmd = NULL;
    asprintf(&cmd, "'%s/pieces/master_ledger/plugins/+x/piece_manager.+x' %s set-state pos_x %d", project_root, zombie_id, nx);
    system(cmd); free(cmd);
    asprintf(&cmd, "'%s/pieces/master_ledger/plugins/+x/piece_manager.+x' %s set-state pos_y %d", project_root, zombie_id, ny);
    system(cmd); free(cmd);

    // PULSE: Ensure render triggers after zombie move
    char *pulse = NULL; asprintf(&pulse, "%s/pieces/display/frame_changed.txt", project_root);
    FILE *pf = fopen(pulse, "a"); if (pf) { fputc('Z', pf); fclose(pf); }
    free(pulse); free(project_root);

    return 0;
}
